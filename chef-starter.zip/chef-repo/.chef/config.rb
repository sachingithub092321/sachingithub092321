# See http://docs.chef.io/workstation/config_rb/ for more information on knife configuration options

current_dir = File.dirname(__FILE__)
log_level                :info
log_location             STDOUT
node_name                "sachinchef092321"
client_key               "#{current_dir}/sachinchef092321.pem"
chef_server_url          "https://api.chef.io/organizations/sachinchef09"
cookbook_path            ["#{current_dir}/../cookbooks"]
